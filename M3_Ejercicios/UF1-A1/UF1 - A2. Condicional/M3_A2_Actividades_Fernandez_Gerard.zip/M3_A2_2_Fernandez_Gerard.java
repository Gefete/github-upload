/*
Alumne: Gerard Fernández Tejada
Curs: CFGS 1r DAM 
Modul: M3 "Programació"
Professor: Isabel Ruiz
Data: 30/09/2021
Nom de la Practica: A2_2
*/
//Demanar un nombre enter i dir si és positiu, negatiu o zero.

package M3_A2_2_Fernandez_Gerard;

import java.util.Scanner;
public class M3_A2_2_Fernandez_Gerard {

    public static void main(String[] args) {
        int enter;
        Scanner teclat = new Scanner(System.in);
        
        System.out.print("Introduzca un numero entero para saber si es positivo o negativo: ");
        enter= teclat.nextInt();
        if (enter>0 ){
            System.out.println("Este numero es mayor que 0 por lo tanto es positivo");  
        }
        
        else if (enter==0 ){
            System.out.println("Este numero es 0");  
            
            }else
                System.out.println("Este numero es negativo");
            {
        }
        
    }
    
}
