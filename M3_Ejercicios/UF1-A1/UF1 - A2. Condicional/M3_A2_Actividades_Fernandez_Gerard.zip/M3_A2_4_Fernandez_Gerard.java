/*
Alumne: Gerard Fernández Tejada
Curs: CFGS 1r DAM 
Modul: M3 "Programació"
Professor: Isabel Ruiz
Data: 30/09/2021
Nom de la Practica: A2_4
*/
/*
Introduir dos nombres enters “a” i “b” que compleixin que a>b i calcular:

        La suma

        La resta

        La multiplicació

        La divisió

Si a<b donar un missatge de error.
*/

package M3_A2_4_Fernandez_Gerard;
//Importamos la clase Scanner para introducir la funcion de lectura de teclado
import java.util.Scanner;

public class M3_A2_4_Fernandez_Gerard {

    public static void main(String[] args) {
        //Variables
        int a, b, suma, resta, multi;
        double div;
        //Definir lectura de teclado
        Scanner teclat = new Scanner(System.in);
        
        //Lectura de valores
        System.out.println("Introduce 2 cifras enteras, que la primera sea mayor si no el programa dara error: ");
        a= teclat.nextInt();
        b= teclat.nextInt();
        
        //Sentencia if / else (si el primer valor "a" es mas grande que el segundo "b" se realiza el calculo, si no dara error)
        if (a>b){
            suma= a+b;
            resta= a-b;
            multi= a*b;
            div= (double) a/b;
            System.out.println("Los resultados de las operaciones es: \n"
            +a+("+")+b+("=")+suma
            +("\n")+a+("-")+b+("=")+resta
            +("\n")+a+("x")+b+("=")+multi
            +("\n")+a+("/")+b+("=")+div);
            } else {
                System.out.println("Error la primera cifra es menor que la segunda");
        }   
        
        
    }
    
}
