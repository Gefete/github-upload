/*
Alumne: Gerard Fernández Tejada
Curs: CFGS 1r DAM 
Modul: M3 "Programació"
Professor: Isabel Ruiz
Data: 30/09/2021
Nom de la Practica: A2_5
*/
/*
Introduir una quantitat N per teclat i :

    si n<500 restar-li un 5%
    si n>=500 i n< 1000 restar-li un 8%
    si n>=1000 i n<=5000 restar-li un 15%
    si n>5000 restar-li un 25%
*/

package M3_A2_5_Fernandez_Gerard;
//Importamos la clase Scanner para introducir la funcion de lectura de teclado
    import java.util.Scanner;

public class M3_A2_5_Fernandez_Gerard {

    public static void main(String[] args) {
        //Variables
        double total, total2, precio, restar, descuento=0;
        int cantidad;
        //Definir lectura de teclado
        Scanner teclado = new Scanner(System.in);
        
        //lectura de valores
        System.out.print("Introduzca el precio del producto que va a comprar: ");
        precio= teclado.nextInt();
        System.out.print("Introduzca la cantidad que va a comprar: ");
        cantidad= teclado.nextInt();
        
        //Introducción de Sentencia if/else if/else
        if(cantidad>=5000){
            descuento=0.25;
            System.out.println("Descuento aplicado: 25%");
        
            } else if (cantidad>=1000) {
                descuento=0.15;
                System.out.println("Descuento aplicado: 15%");
                } else if (cantidad>=500) {
                    descuento=0.08;
                    System.out.println("Descuento aplicado: 8%");
                    } else if (cantidad<=0) {
                        System.out.println("Error numero de cantidad nulo");
                        } else {
                            descuento=0.05;
                            System.out.println("Descuento aplicado: 5%");
        }
        
        //Operacion con los datos que nos proporciona la sentencia
        restar= precio * descuento;
        total= (precio - restar)*cantidad;
        total2= precio * cantidad;
        System.out.println("precio sin descuento: "+total2+"\nEl total a pagar con descuento aplicado: "+ total+"€");
        
    }
    
}
