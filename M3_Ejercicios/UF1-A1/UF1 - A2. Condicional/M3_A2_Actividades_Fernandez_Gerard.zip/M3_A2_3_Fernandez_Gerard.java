/*
Alumne: Gerard Fernández Tejada
Curs: CFGS 1r DAM 
Modul: M3 "Programació"
Professor: Isabel Ruiz
Data: 30/09/2021
Nom de la Practica: A2_3
*/

//Demanar dos nombres enters i dir quin és el més gran o si són iguals.

package M3_A2_3_Fernandez_Gerard;
//Importamos la clase Scanner para introducir la funcion de lectura de teclado
    import java.util.Scanner;
public class M3_A2_3_Fernandez_Gerard {

    public static void main(String[] args) {
        //Variables
        int num1, num2;
        //Definir lectura de teclado
        Scanner teclat = new Scanner(System.in);
        
        
        System.out.println("A continución tiene que introducir 2 cifras, se compararan y se dira si son iguales o no");
        //Lectura de valores
        num1= teclat.nextInt();
        num2= teclat.nextInt();
        
        //Sentencia if / else if / else
        if (num1>num2){
            System.out.println(num1+" es mayor");
                }else if (num1==num2){
                    System.out.println(num2+" son iguales");
                    } else {
                        System.out.println(num2+" es mayor");
        }
    }
    
}
