
/*
Alumne: Gerard Fernández Tejada
Curs: CFGS 1r DAM 
Modul: M3 "Programació"
Professor: Isabel Ruiz
Data: 30/09/2021
Nom de la Practica: A2_1
*/
//Demanar un nombre enter i dir si és parell o senar.
package M3_A2_1_Fernandez_Gerard;

    import java.util.Scanner;

public class M3_A2_1_Fernandez_Gerard {

    public static void main(String[] args) {
        //define la entrada de teclado
        Scanner teclat = new Scanner(System.in);
        //variables enteras
        int valor, resto;
        
        System.out.println("Introduzca un numero para saber si es par o impar: ");
        valor = teclat.nextInt();
        //Calculo modulo (coge el resultado)
        resto = valor % 2;
        if (resto==0) {
            System.out.println("El numero es par");
        } else {
            System.out.println("El numero es impar");
        }
    }
    
}
